import com.sun.jna.platform.win32.WinNT
import main.Properties
import DataParser
import DataParser.DataType
import UI
import Process
import Memory

/**
 * Ponto de entrada da aplicação. Após a seleção do processo, os usuários
 * podem emitir comandos interativos para vasculhar e alterar valores na memória.
 * Comandos suportados:
 *  - search <tipo> <valor> : inicia uma nova busca na memória pelo valor.
 *  - filter <valor>       : refina os endereços encontrados usando o novo valor.
 *  - alter <valor>        : altera todos os endereços atualmente listados para o novo valor.
 *  - exit/quit            : retorna para a seleção de processo.
 */
fun main() {
    val language = "ptBR"
    while (true) {
        val process = Process.selectProcess(language)
        val handle = Process.open(process.processID)
        if (handle == null) {
            println(Properties.get("$language.error.processCannotBeOpened", mapOf("pid" to process.processID.toString())))
            continue
        }
        var currentType: DataType? = null
        var addresses: MutableList<Long> = mutableListOf()
        var patternPerAddress: MutableMap<Long, ByteArray> = mutableMapOf()
        while (true) {
            print("> ")
            val input = readlnOrNull()?.trim() ?: ""
            if (input.isEmpty()) continue
            val parts = input.split(" ")
            val command = parts[0].lowercase()
            when (command) {
                "search" -> {
                    if (parts.size < 3) {
                        println("Uso: search <tipo> <valor>")
                        continue
                    }
                    val typeStr = parts[1]
                    val value = parts.subList(2, parts.size).joinToString(" ")
                    try {
                        val dt = DataParser.parseType(typeStr)
                        currentType = dt
                        addresses.clear()
                        patternPerAddress.clear()
                        when (dt) {
                            DataType.STRING -> {
                                val patternUtf8 = DataParser.toBytes(DataType.STRING, value)
                                val resultsUtf8 = Memory.searchMemory(handle, patternUtf8)
                                for (addr in resultsUtf8) {
                                    val filtered = Memory.filterStringExactMatches(handle, listOf(addr), patternUtf8)
                                    if (filtered.isNotEmpty()) {
                                        addresses.add(addr)
                                        patternPerAddress[addr] = patternUtf8
                                    }
                                }
                                val patternUtf16 = DataParser.toBytesUtf16LE(value)
                                val resultsUtf16 = Memory.searchMemory(handle, patternUtf16)
                                for (addr in resultsUtf16) {
                                    val filtered = Memory.filterStringExactMatches(handle, listOf(addr), patternUtf16)
                                    if (filtered.isNotEmpty()) {
                                        addresses.add(addr)
                                        patternPerAddress[addr] = patternUtf16
                                    }
                                }
                            }
                            else -> {
                                val pattern = DataParser.toBytes(dt, value)
                                val results = Memory.searchMemory(handle, pattern)
                                addresses.addAll(results)
                                for (addr in results) {
                                    patternPerAddress[addr] = pattern
                                }
                            }
                        }
                        println(Properties.get("$language.info.foundAddresses", mapOf("count" to addresses.size.toString())))
                        if (addresses.isNotEmpty()) {
                            printAddresses(addresses)
                        } else {
                            println("Nenhum endereço encontrado.")
                        }
                    } catch (ex: Exception) {
                        println(Properties.get("$language.error.invalidDataType"))
                    }
                }
                "filter" -> {
                    if (currentType == null || addresses.isEmpty()) {
                        println("Nenhuma busca anterior. Use 'search' primeiro.")
                        continue
                    }
                    if (parts.size < 2) {
                        println("Uso: filter <valor>")
                        continue
                    }
                    val value = parts.subList(1, parts.size).joinToString(" ")
                    try {
                        when (currentType) {
                            DataType.STRING -> {
                                val patternUtf8 = DataParser.toBytes(DataType.STRING, value)
                                val patternUtf16 = DataParser.toBytesUtf16LE(value)
                                val newAddresses = mutableListOf<Long>()
                                val newPatterns = mutableMapOf<Long, ByteArray>()
                                for ((addr, oldPattern) in patternPerAddress) {
                                    val newPattern = if (oldPattern.size == patternUtf8.size) patternUtf8 else patternUtf16
                                    val filtered = Memory.filterStringExactMatches(handle, listOf(addr), newPattern)
                                    if (filtered.isNotEmpty()) {
                                        newAddresses.add(addr)
                                        newPatterns[addr] = newPattern
                                    }
                                }
                                addresses = newAddresses
                                patternPerAddress = newPatterns
                            }
                            else -> {
                                val pattern = DataParser.toBytes(currentType, value)
                                val filtered = Memory.filterAddresses(handle, addresses, pattern)
                                addresses = filtered.toMutableList()
                                val newPatterns = mutableMapOf<Long, ByteArray>()
                                for (addr in addresses) {
                                    newPatterns[addr] = pattern
                                }
                                patternPerAddress = newPatterns
                            }
                        }
                        println(Properties.get("$language.info.remainingAddresses", mapOf("count" to addresses.size.toString())))
                        if (addresses.isNotEmpty()) {
                            printAddresses(addresses)
                        } else {
                            println("Nenhum endereço remanescente.")
                        }
                    } catch (ex: Exception) {
                        println("Valor inválido ou não compatível com o tipo atual.")
                    }
                }
                "alter" -> {
                    if (currentType == null || addresses.isEmpty()) {
                        println("Nenhuma busca anterior. Use 'search' primeiro.")
                        continue
                    }
                    if (parts.size < 2) {
                        println("Uso: alter <valor>")
                        continue
                    }
                    val value = parts.subList(1, parts.size).joinToString(" ")
                    try {
                        when (currentType) {
                            DataType.STRING -> {
                                val newUtf8 = DataParser.toBytes(DataType.STRING, value)
                                val newUtf16 = DataParser.toBytesUtf16LE(value)
                                for (addr in addresses) {
                                    val oldPattern = patternPerAddress[addr]!!
                                    val newPattern = if (oldPattern.size == newUtf8.size) newUtf8 else newUtf16
                                    Memory.write(handle, addr, newPattern)
                                    patternPerAddress[addr] = newPattern
                                }
                            }
                            else -> {
                                val newPattern = DataParser.toBytes(currentType, value)
                                for (addr in addresses) {
                                    Memory.write(handle, addr, newPattern)
                                    patternPerAddress[addr] = newPattern
                                }
                            }
                        }
                        println("Alterações aplicadas.")
                        printAddresses(addresses)
                    } catch (ex: Exception) {
                        println("Erro ao alterar valores: ${ex.message}")
                    }
                }
                "exit", "quit" -> {
                    break
                }
                else -> {
                    println("Comando inválido. Use search, filter, alter ou exit.")
                }
            }
        }
        Memory.close(handle)
    }
}

fun printAddresses(addresses: List<Long>) {
    addresses.forEachIndexed { index, addr ->
        println(UI.printLine("${index + 1}.", addr.toString(16)))
    }
}